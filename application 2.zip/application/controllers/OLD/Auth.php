<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('login_mod');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger">
  		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>', '</div>');
	}


	function index()
	{
		$this->form_validation->set_rules('username', 'Username', 'required|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'required|xss_clean|callback_check_password');


		if ($this->form_validation->run() == FALSE) {
			$data['title'] = "Login";
			$this->load->view('login', $data);
		} 

		else 
		{
			redirect(base_url().'home','refresh');
		}
			

		
	}





	function check_password($password){

		//Get password yang username nya sesuai yg diinput
		$username = $this->input->post('username');
		$res_pass = $this->login_mod->get_password($username);

		if($res_pass){
			//decrypt password yang ada di DB
			$pass = $this->encrypt->decode($res_pass['password']);

				//jika password yang ada di db sama dengan yang diinput
				if($pass == $this->input->post('password')){
					$res_login = $this->login_mod->login($username);
					
					if($res_login){
						$this->login_mod->update_lastlogin($username);
						foreach ($res_login as $row) {
							$this->session->set_userdata('id_user', $row->id_user);
							$this->session->set_userdata('username', $row->username);
							$this->session->set_userdata('nama', $row->nama_lengkap);
							$this->session->set_userdata('level', $row->level);
						}
						return TRUE;
					}
				}

				//jika password tidak sama dengan yang diinput
					else {
						$this->form_validation->set_message('check_password', 'Invalid username or password');
     		 			return FALSE;
					}
				}

		
		else
		{
			 $this->form_validation->set_message('check_password', 'Invalid username or password');
     		 return FALSE;
		}

	}
        
    function logout(){
    	$this->session->sess_destroy();
    	redirect(base_url().'login','refresh');
    }


    function registrasi(){

    		$this->form_validation->set_rules('nama', 'Nama Lengkap', 'required|xss_clean');
			$this->form_validation->set_rules('email', 'Email', 'valid_email|required|xss_clean');
			$this->form_validation->set_rules('telp', 'Telepon', 'numeric|required|xss_clean');
			$this->form_validation->set_rules('username', 'Username', 'required|xss_clean|alpha_numeric|callback_cek_username');
			$this->form_validation->set_rules('password', 'Password', 'required|xss_clean');

			if ($this->form_validation->run() == FALSE) {
					$data['question'] = $this->login_mod->get_question()->result();
				 	$this->load->view('registrasi', $data);
			}	
				
			else {
					$this->login_mod->insert_user();
					redirect(base_url().'login','refresh');
			}			
	}
	

	public function cek_username($username){

		$username = $this->input->post('username');

		$result = $this->login_mod->cek_username($username);


		if(!$result){
			$this->form_validation->set_message('cek_username', 'Username sudah terdaftar');
     		return FALSE;
		}
		else{
			return TRUE;
		}

	}
}
