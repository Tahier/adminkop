<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(empty($this->session->userdata('id_user'))){
			redirect(base_url().'login','refresh');
		}
		$this->load->model('produk_mod');
		$this->load->helper('form');
		$this->load->library('form_validation');
	}

	function produk_corridor(){
			$owner_segment =$this->session->userdata('owner');

			switch ($owner_segment) {
				case '1':
					$this->session->set_userdata('owner','1');
					redirect('produk_owner');
					break;
				case '2':
					$this->session->set_userdata('owner','2');
					redirect('produk_koperasi');
					break;
				case '3':
					$this->session->set_userdata('owner','3');
					redirect('produk_anggota');
					break;
				default:
					$this->session->set_userdata('owner','');
					break;
			}

			echo $owner_segment;
	}


	function produk_data(){

		if($this->session->userdata('level') == '1'){
			$owner_segment = $this->uri->segment(1);


			switch ($owner_segment) {
				case 'produk_owner':
					$this->session->set_userdata('owner','1');
					$title = "Data Produk Admin";
					break;
				case 'produk_koperasi':
					$this->session->set_userdata('owner','2');
					$title = "Data Produk Koperasi";
					break;
				case 'produk_anggota':
					$this->session->set_userdata('owner','3');
					$title = "Data Produk Anggota Koperasi";
					break;
				default:
					$this->session->set_userdata('owner','');
					break;
			}


		}
		

		$data['produk'] = $this->produk_mod->get_all_produk()->result();

		// echo "<pre>";
		// var_dump($data['produk']);
		// echo "</pre>";

		// echo $this->db->last_query();
		// die();
		$data['no'] = "1";
		$data['title'] = $title;
		$this->load->view('produk/produk_data', $data);
	}


	function add_produk(){

		$this->form_validation->set_rules('nama', 'Nama', 'required|xss_clean');
		$this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required|xss_clean');
		// $this->form_validation->set_rules('warna', 'Warna', 'required|xss_clean');
		// $this->form_validation->set_rules('tipe', 'Tipe', 'required|xss_clean');
		$this->form_validation->set_rules('kategori', 'Kategori', 'required|xss_clean');
		$this->form_validation->set_rules('berat', 'Berat', 'required|xss_clean');
		$this->form_validation->set_rules('price_n', 'Harga Normal', 'required|xss_clean');
		$this->form_validation->set_rules('price_n', 'Harga Normal', 'required|xss_clean');
		$this->form_validation->set_rules('qty', 'Jumlah Stok', 'required|xss_clean');
		// $this->form_validation->set_rules('terjual', 'Terjual', 'required|xss_clean');


		if ($this->form_validation->run() == FALSE) {
			$data['kategori'] = $this->produk_mod->get_all_produk_kategori()->result();
			$data['title'] = "Tambah Data Produk";
			$this->load->view('produk/add_produk', $data);
		} 
		else {
				$this->produk_mod->add_produk();
				$this->session->set_flashdata('msg','Data Produk berhasil ditambahkan');
				redirect(base_url().'produk','refresh');
		}
	}




	function detail_produk(){
		$this->session->set_userdata('id', $this->uri->rsegment(3));
		redirect(base_url().'produk_detail','refresh');
	}

	function delete_produk(){
		$this->session->set_userdata('id', $this->uri->rsegment(3));
		redirect(base_url().'produk_delete','refresh');
	}


	function update_produk(){
	
		$this->form_validation->set_rules('nama', 'Nama', 'required|xss_clean');
		$this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required|xss_clean');
		// $this->form_validation->set_rules('warna', 'Warna', 'required|xss_clean');
		// $this->form_validation->set_rules('tipe', 'Tipe', 'required|xss_clean');
		$this->form_validation->set_rules('kategori', 'Kategori', 'required|xss_clean');
		$this->form_validation->set_rules('berat', 'Berat', 'required|xss_clean');
		$this->form_validation->set_rules('price_n', 'Harga Normal', 'required|xss_clean');
		$this->form_validation->set_rules('price_n', 'Harga Normal', 'required|xss_clean');
		$this->form_validation->set_rules('qty', 'Jumlah Stok', 'required|xss_clean');
		// $this->form_validation->set_rules('terjual', 'Terjual', 'required|xss_clean');


		if ($this->form_validation->run() == FALSE) {
			$data['produk'] = $this->produk_mod->get_produk_by_id()->row_array();	
			$data['produk'] = $this->produk_mod->get_produk_by_id()->row_array();				
			$data['photo'] = $this->produk_mod->get_produk_foto()->result();
			$data['kategori'] = $this->produk_mod->get_all_produk_kategori()->result();
			$data['no'] = "1";
			$data['title'] = "Edit Data Produk";
			$data['kategori'] = $this->produk_mod->get_produk_kategori()->result();
			$this->load->view('produk/detail_produk', $data);
		} 
		else {
				$this->produk_mod->update_produk();
				$this->session->set_flashdata('msg','Data Produk '.$this->input->post('nama').' berhasil diperbaharui');
				redirect(base_url().'detail_produk/'.$this->session->userdata('id'),'refresh');
		}
	}

	function produk_detail(){
		$owner_segment =$this->session->userdata('owner');
		if($owner_segment == '2'){
			// echo "koperasi";

			$data['produk'] = $this->produk_mod->get_produk_by_id_kop();
		}
		else{
			// echo "bukan koperasi";
			$data['produk'] = $this->produk_mod->get_produk_by_id();	
		}



		if($data['produk']->num_rows() > 0){
			$data['photo'] = $this->produk_mod->get_produk_foto()->result();
			$data['produk'] = $data['produk']->row_array();
			$data['kategori'] = $this->produk_mod->get_all_produk_kategori()->result();
			$data['no'] = "1";
			$data['title'] = "Edit Data Produk";
			$this->load->view('produk/detail_produk', $data);
		}
		else{
			redirect('not_found');
		}

		

	}


	function upload_produk_foto(){
		$config['upload_path'] = 'assets/images/produk';
		$config['allowed_types'] = 'jpg|png';
		$config['encrypt_name'] = TRUE;
		
		$this->load->library('upload', $config);
		
		if ( !$this->upload->do_upload('photo')){
			$this->session->set_userdata('error', $this->upload->display_errors());
			redirect(base_url().'detail_produk/'.$this->session->userdata('id'),'refresh');
		}
		else{
			$this->session->set_userdata('error', "");
			$this->produk_mod->add_produk_foto($this->upload->data('file_name'));
			redirect(base_url().'detail_produk/'.$this->session->userdata('id'),'refresh');
		}
	}





	function produk_delete(){
		$this->produk_mod->delete_produk();
		redirect(base_url().'produk','refresh');

	}

	function delete_produk_foto(){
		$this->session->set_userdata('id_foto', $this->uri->rsegment(3));
		redirect(base_url().'produk_foto_delete','refresh');
	}

	function produk_foto_delete(){
		$this->produk_mod->delete_produk_foto();
		redirect(base_url().'detail_produk/'.$this->session->userdata('id'),'refresh');
	}



	function produk_kategori_data(){
			$data['kategori'] = $this->produk_mod->get_all_produk_kategori()->result();
			$data['no'] = "1";
			$data['title'] = 'Data Kategori Produk';
			$this->load->view('produk/produk_kategori_data', $data);

	}


	function add_produk_kategori(){

		$this->form_validation->set_rules('nama', 'Nama', 'required|xss_clean');


		if ($this->form_validation->run() == False) {
			$data['title'] = "Tambah Data Kategori Produk";
			$this->load->view('produk/add_produk_kategori',$data);
		} else {
			$this->produk_mod->add_produk_kategori();
			$this->session->set_flashdata('msg','Data Kategori Produk berhasil ditambahkan');
			redirect(base_url().'produk_kategori','refresh');
		}
		
	}

	function update_produk_kategori(){
		$this->session->set_userdata('id', $this->uri->rsegment(3));
		redirect(base_url().'produk_kategori_update','refresh');
	}

	function produk_kategori_update(){
		$this->form_validation->set_rules('nama', 'Nama', 'required|xss_clean');


		if ($this->form_validation->run() == False) {
			$data['kategori'] = $this->produk_mod->get_produk_kategori_by_id()->row_array();
			$this->load->view('produk/edit_produk_kategori', $data);
		} else {
			$this->produk_mod->update_produk_kategori();
			$nama_kategori = $this->produk_mod->get_produk_kategori_by_id()->row()->nama;
			$this->session->set_flashdata('msg','Data Kategori '.$nama_kategori.' Produk berhasil diperbaharui');
			redirect(base_url().'produk_kategori','refresh');
		}
	}

	function delete_produk_kategori(){
		$this->session->set_userdata('id', $this->uri->rsegment(3));

		redirect(base_url().'produk_kategori_delete','refresh');
	}

	function produk_kategori_delete(){
		$nama_kategori = $this->produk_mod->get_produk_kategori_by_id();
		if($nama_kategori->num_rows() > 0){
			$nama_kategori = $nama_kategori->row()->nama;
			$this->produk_mod->delete_produk_kategori();
			$this->session->set_flashdata('msg','Data Kategori '.$nama_kategori.' Produk berhasil dihapus');
			redirect(base_url().'produk_kategori','refresh');
		}
		else{
			redirect('not_found');
		}


			
	}


	function history_produk(){
		$this->session->set_userdata('id', $this->uri->rsegment(3));
		redirect(base_url().'catatan_produk','refresh');

	}

	function catatan_produk(){
		$owner_segment =$this->session->userdata('owner');
		if($owner_segment == '2'){
			$data['produk'] = $this->produk_mod->get_produk_history_by_id_kop();
		}
		else{
			$data['produk'] = $this->produk_mod->get_produk_history_by_id();	
		}


		if($data['produk']->num_rows() > 0){
			$data['produk'] = $data['produk']->result();


			$data['no'] = "1";
			$data['title'] = "History Management Data Produk";
			$this->load->view('produk/catatan_produk', $data);
		}
		else{
			redirect('not_found');
		}

		
	}
}

/* End of file Produk.php */
/* Location: ./application/controllers/Produk.php */