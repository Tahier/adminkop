<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_mod extends CI_Model {

	public function get_password($username){
		$this->db->select('password');
		$this->db->where('username', $username);
		$result = $this->db->get('user_info');


		if($result->num_rows() == 1){
			return $result->row_array();
		}
		else {
			return FALSE;
		}
		
	}

	public function get_question(){
		return $this->db->get('user_question');
	}

	function login($username){
		$this->db->select('user_info.id_user, user_info.username, user_info.password, user_detail.nama_lengkap, user_info.level');
		$this->db->where('user_info.username', $username);
		$this->db->from('user_info');
		$this->db->join('user_detail', 'user_detail.id_user = user_info.id_user');

		$result = $this->db->get();

		if($result->num_rows() == 1){
			return $result->result();
		}
		else {
			return FALSE;
		}

	}

	function update_lastlogin($username){
		$this->db->where('username', $username);

		$object = array('last_login' => date("Y-m-d H:i:s"),
						'session_token' => "5".time() );


		$this->db->update('user_info', $object);
	}

	
	
	function insert_user(){

		$id_user = "9".time();
		$password = $this->encrypt->encode($this->input->post('password'));
		$user_info = array('id_user' => $id_user,
					  'username' => $this->input->post('username'),
					  'password' => $password,
					  'status_active' => 1,
					  'level' => "3",
					  'service_time' => date('Y/m/d H:i:s'),
					  'service_action' => 'insert');

		$user_detail = array('id_user' => $id_user,
						'nama_lengkap' => $this->input->post('nama'),
						'alamat' => $this->input->post('alamat'),
						'jenis_kelamin' => $this->input->post('jkel'),
						'email' => $this->input->post('email'),
						'telp' => $this->input->post('telepon'),
						'service_time' => date('Y/m/d H:i:s'),
						'service_action' => 'insert');
		
		foreach ($this->get_question()->result() as $row){
			$question_answer = array('id_user' => $id_user,
								 	 'id_pertanyaan' => $row->id_pertanyaan,
								 	 'jawaban' => $this->input->post($row->id_pertanyaan));

			$this->db->insert('user_answer_question', $question_answer);
		}
		

		$this->db->insert("user_info", $user_info);
		$this->db->insert("user_detail", $user_detail);
	}

	function cek_username($username){

		$this->db->select('username');
		$this->db->where('username', $username);
		$query = $this->db->get('user_info');

		if($query->num_rows() == 0){
			return TRUE;
		}
		else {
			return FALSE;
		}

	}
}

/* End of file login_mod.php */
/* Location: ./application/models/login_mod.php */