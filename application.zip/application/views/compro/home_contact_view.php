<div class="page-banner" style="padding:70px 0 20px 0;background: url(images/slide-02-bg.jpg) center #f9f9f9;">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h2 class="text-center">Kontak</h2>
        <!-- <p>We Are Professional</p> -->
      </div>
    </div>
  </div>
</div>

<div class="contact" style="margin:50px 0px 100px 0px;">
  <div class="container">
   
      <div class="col-md-6">
        <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9933.460884430251!2d-0.13301252240929382!3d51.50651527467666!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a00baf21de75%3A0x52963a5addd52a99!2sLondon%2C+UK!5e0!3m2!1sen!2snp!4v1414314152341" width="100%" height="300" frameborder="0"></iframe> 
        </div>
      </div>

      <div class="col-md-6">
       

            <!-- Classic Heading -->
            <h4 class="page-header"><span>Information</span></h4>

            <!-- Some Info -->
            <!-- Divider -->
            <div class="hr1" style="margin-bottom:10px;"></div>

            <!-- Info - Icons List -->
            <ul class="list-unstyled">
              <li><i class="fa fa-globe">  </i> <strong>Address:</strong> 1234 Street Name, Indonesia.</li>
              <li><i class="fa fa-envelope-o"></i> <strong>Email:</strong> info@yourcompany.com</li>
              <li><i class="fa fa-mobile"></i> <strong>Phone:</strong> +12 345 678 001</li>
            </ul>

            <!-- Divider -->
            <hr>

            <!-- Classic Heading -->
            <h4 class="page-header"><span>Working Hours</span></h4>

            <!-- Info - List -->
            <ul class="list-unstyled">
              <li><strong>Monday - Friday</strong> - 9am to 5pm</li>
              <li><strong>Saturday</strong> - 9am to 2pm</li>
              <li><strong>Sunday</strong> - Closed</li>
            </ul>

        
      </div>
 
  </div>
</div>