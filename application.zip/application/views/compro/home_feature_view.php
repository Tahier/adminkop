<div class="page-banner" style="padding:70px 0 20px 0;background: url(images/slide-02-bg.jpg) center #f9f9f9;">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h2 class="text-center">Fitur Kami</h2>
        <!-- <p>We Are Professional</p> -->
      </div>
    </div>
  </div>
</div>

<div class="contact" style="margin:50px 0px;">
  <div class="container">
    
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <img src="<?php echo base_url('assets/compro/IMAGE/mockup_aboutus.png'); ?>" alt="...">
          <div class="caption">
            <h3>Clean Modern Code</h3>
            <p>Sed ut perspiciatis unde omnis iste natus error voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis quasi architect.</p>
            <p class="hidden">
              <a href="#" class="btn btn-primary" role="button">Button</a> 
              <a href="#" class="btn btn-default" role="button">Button</a>
            </p>
          </div>
        </div>
      </div>

      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <img src="<?php echo base_url('assets/compro/IMAGE/mockup_aboutus.png'); ?>" alt="...">
          <div class="caption">
            <h3>High Quality</h3>
            <p>Sed ut perspiciatis unde omnis iste natus error voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis quasi architect.</p>
            <p class="hidden">
              <a href="#" class="btn btn-primary" role="button">Button</a> 
              <a href="#" class="btn btn-default" role="button">Button</a>
            </p>
          </div>
        </div>
      </div>

      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <img src="<?php echo base_url('assets/compro/IMAGE/mockup_aboutus.png'); ?>" alt="...">
          <div class="caption">
            <h3>Great Support</h3>
            <p>Sed ut perspiciatis unde omnis iste natus error voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis quasi architect.</p>
            <p class="hidden">
              <a href="#" class="btn btn-primary" role="button">Button</a> 
              <a href="#" class="btn btn-default" role="button">Button</a>
            </p>
          </div>
        </div>
      </div>
    
  </div>
</div>