<div class="login-box" style="margin-top:0px;">
  <div class="login-box-body">
    <h4><center>Selamat <?php echo $member_name; ?>,<br>akun Anda berhasil diaktifkan.</center></h4>
    <p class="login-box-msg">
      Selanjutnya anda dapat login (<a href="<?php echo site_url('auth/login'); ?>">klik di sini</a>) untuk mengirim syarat dan dokumen pengajuan pengesahan Masterplan / Siteplan.
    </p>
  </div><!-- /.login-box-body -->
</div><!-- /.login-box -->