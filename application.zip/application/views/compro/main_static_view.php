<!DOCTYPE HTML>
<html>
   <head>
      <title>Koperasi</title>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
      <meta name="keywords" content="Rasendriya, Illustrator, ANimation, Animasi, Animasi Indonesia, Film,  Production, Production House, PH">
      <meta name="author" content="Pijar International - pijar-int.com">
      <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
      <link rel="stylesheet" href="<?php echo base_url('assets/compro');?>/LTE/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> 
      <link href="<?php echo base_url('assets/compro');?>/LTE/css/AdminLTE.css" rel="stylesheet" type="text/css" />
      <link rel="stylesheet" href="<?php echo base_url('assets/compro');?>/LTE/dist/css/skins/_all-skins.min.css">
      <link rel="stylesheet" href="<?php echo base_url('assets/compro');?>/LTE/plugins/iCheck/flat/blue.css">
      <link rel="stylesheet" href="<?php echo base_url('assets/compro');?>/LTE/plugins/morris/morris.css">
      <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>

      <script src="<?php echo base_url('assets/compro');?>/LTE/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
      <script src="<?php echo base_url('assets/compro');?>/LTE/plugins/sparkline/jquery.sparkline.min.js"></script>
      <script src="<?php echo base_url('assets/compro');?>/LTE/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
      <script src="<?php echo base_url('assets/compro');?>/LTE/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
      <script src="<?php echo base_url('assets/compro');?>/LTE/dist/js/app.min.js"></script>
      <script src="<?php echo base_url('assets/compro');?>/panelapp.js"></script>

      <link href='http://fonts.googleapis.com/css?family=Neuton&subset=latin' rel='stylesheet' type='text/css'>
      <link href="<?php echo base_url('assets/compro');?>/new_kibi.css" rel="stylesheet" type="text/css" />
      <script>
         // (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
         // (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
         // m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
         // })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
         
         // ga('create', 'UA-44204568-3', 'auto');
         // ga('send', 'pageview');
      </script>
   </head>

   <body>
    

      <?php 
         $this->load->view(@$page);
      ?> 


   </body>
</html>