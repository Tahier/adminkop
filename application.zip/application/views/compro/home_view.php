<div  class="main_header">
   <section id="hero-wrapper" class="face-control" data-height-type="auto" data-height-value="100" >
      <span class="target target-top background--dark"></span>
      <span class="target target-bottom background--dark"></span>
      <figure class="hero-image hero-item" style="transform: translate3d(0px, 0px, 0px);">
         <center>
            <img src="<?php echo base_url('assets/compro');?>/IMAGE/cover_hero.png" alt="">
         </center>
      </figure>
   </section>
</div>
<div  class="main_about_us" style="padding: 10px 0;border-bottom:1px solid #D4D4D4">
   <div class="container">
      <div class="row">
         <div class="col-md-12 col-xs-12">
            <div class="text-center">
               <marquee>
                  Welcome to our offical website. We gives people better ways to connect to their money and to each other.
               </marquee>
            </div>
         </div>
      </div>
   </div>
</div>
<div  class="main_about_us">
   <div class="container">
      <div class="row">
         <div class="col-md-8 col-md-offset-2 col-xs-12">
            <div class="text-center">
               <h2>GERAI LUMRAH</h2>
               <p>
                  We gives people better ways to connect to their money and to each other, helping them safely access and move their money and offering a choice of how they would like to pay or be paid.
               </p>
            </div>
         </div>
      </div>
   </div>
</div>

<div class="clear-both"></div>


<div  class="main_portofolio">
   <div class="container">
      <br>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo site_url('pulsa'); ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_pulsa.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Pulsa</p>
                  <h2 class="item-title">Topup Pulsa Handphone Lebih Mudah</h2>
                  <!-- <h3 class="item-cat">Motion Graphic for BIAF 15</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo site_url('store'); ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_online_store.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Online Shopping</p>
                  <h2 class="item-title">Harga Terbaik kami hadirkan untuk anda</h2>
                  <!-- <h3 class="item-cat">3D Modelling Boogie</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_wesel.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Wesel Instan</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">VFX for Short Movie</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_pembayaran.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Jasa Pembayaran</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">3D Modelling Boogie</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_reservasi.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Reservasi</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">Motion Graphic for BIAF 15</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_pinjaman.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Pinjaman</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">VFX for Short Movie</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_pegadaian.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Pegadaian</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">3D Character  for Virtual Idol</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_penukaran_uang.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Penukaran Uang</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">VFX for Short Movie</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_asuransi.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Asuransi & Investasi</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">3D Modelling Boogie</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>
      
      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_emas.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Emas</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">Motion Graphic for BIAF 15</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_infaq.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Shodaqoh, Infaq & Zakat</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">3D Character  for Virtual Idol</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      <div class="col-md-3 col-xs-6" style="padding:0 0px;">
         <a href="<?php echo "#"; ?>">
            <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_tagihan.png');?>" style="width:100%;">
            <div class="item-hover">
               <div class="item-meta">
                  <p class="item-type">Bayar Tagihan</p>
                  <h2 class="item-title">Coming Soon</h2>
                  <!-- <h3 class="item-cat">3D Character  for Virtual Idol</h3> -->
                  <span class="thumb-extra-info"></span>
               </div>
            </div>
         </a>
      </div>

      
   </div>
</div>

<div class="clear-both"></div>

<div class="col-md-12 col-sm-7">

</div>
<div  class="main_portofolio" style="margin:150px 0;">
   <div class="container">
       <div class="col-md-7 col-xs-12">
         <img src="<?php echo base_url();?>assets/compro/landing_page/hero_large.jpg" class="img-responsive">
      </div>
      <div class="col-md-5 col-xs-12">
         <div class="wr-element" style="margin-top:200px;">
           <div class="product style-1">
               <div class="p-info">
                   <span class="cat">Layanan kami</span>
                   <h4><a href="javascript:void()" >Bayar apapun, di mana pun.</a></h4>
                   <p>
                     Bayar barang atau jasa dengan mudah dan lebih aman, cukup dengan alamat email atau nomor telepon. Di mana pun anda berada, pembayaran Anda akan diterima dengan senang hati.
                   </p>
                   <div class="p-countdown light"></div>
               </div>
            </div>
         </div>
         <h3></h3>

         <p>

         </p>
      </div>
     
      
   </div>
</div>

<div class="clear-both"></div>

<div class="page-section v4-three" style="height:610px;margin:150px 0 ;">
    <div class="container" >
        <div class="row">
            <div class="col-md-6">
                <h3 class="title-2 textup text-left mgt90" style="margin-top:200px;padding:10px;">Alihkan telepon Anda ke mode belanja.</h3>
                <p class="sub-title text-left mgb10" style="color:white;padding:10px;">Berbelanja penawaran-penawaran yang ada bahkan saat dalam perjalanan. Semua penawaran yang tersedia, tanpa perlu menunggu. Cara yang lebih mudah dan lebih aman untuk membayar saat Anda bepergian.</p>
            </div>
            <div class="col-md-6">
            </div>
            
        </div>
        <!-- .row -->
    </div>
    <!-- .container -->
</div>


<div class="page-section v4-two pdt30" style="margin:150px 0;">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="wr-element">
                  <center>
                    <div class="product style-2">
                        <div class="p-image">
                           <img src="<?php echo base_url();?>assets/compro/landing_page/register.png" class="img-responsive">
                        </div>
                        <div class="p-info">
                            <h4><a href="shop_details_fullwidth.html">Register Sekarang</a></h4>
                            <p>
                            Mendaftar secara online hari ini untuk mulai menikmati manfaat dari kami segera .
                            </p>
                        </div>
                    </div>
                  </center>
                </div>
            </div>
            <!-- .col-md-4 -->
            <div class="col-md-4">
                <div class="wr-element">
                  <center>
                    <div class="product style-2">
                        <div class="p-image">
                           <img src="<?php echo base_url();?>assets/compro/landing_page/paid.png" class="img-responsive">
                        </div>
                        <div class="p-info">
                            <h4><a href="shop_details_fullwidth.html">Register Sekarang</a></h4>
                            <p>
                            Mengisi ulang akun Anda dari rekening bank dalam 3 langkah mudah .
                            </p>
                        </div>
                    </div>
                  </center>
                </div>
            </div>
            <!-- .col-md-4 -->
            <div class="col-md-4">
                <div class="wr-element">
                  <center>
                    <div class="product style-2">
                        <div class="p-image">
                           <img src="<?php echo base_url();?>assets/compro/landing_page/services.png" class="img-responsive">
                        </div>
                        <div class="p-info">
                            <h4><a href="shop_details_fullwidth.html">Layanan Kami</a></h4>
                            <p>
                            One Stop SOlution untuk setiap pembayaran dan pembelian anda.
                            </p>
                        </div>
                    </div>
                  </center>
                </div>
            </div>
            <!-- .col-md-4 -->
        </div>
        <!-- .row -->
    </div>
    <!-- .container -->
</div>
